from django.db import models
class UserRegistration(models.Model):
    name = models.CharField(max_length=100)
    age = models.PositiveIntegerField()
    message = models.TextField(blank=True)
    payment_receipt = models.ImageField(upload_to='receipts/', null=True, blank=True)
    phone_number = models.CharField(max_length=15, blank=True, null=True)  # فیلد شماره تماس
    address = models.TextField(blank=True, null=True)  # فیلد آدرس
    profile_picture = models.ImageField(upload_to='profile_pictures/', null=True, blank=True)  # فیلد عکس پروفایل
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name



class MemoryAlbum(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    image = models.ImageField(upload_to='album/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
