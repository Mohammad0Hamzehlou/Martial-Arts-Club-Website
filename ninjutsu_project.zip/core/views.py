from django.shortcuts import render, redirect
from .models import UserRegistration, MemoryAlbum
from .forms import UserRegistrationForm

def homepage(request):
    return render(request, 'home.html')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('homepage')
    else:
        form = UserRegistrationForm()
    return render(request, 'register.html', {'form': form})

def memory_album(request):
    memories = MemoryAlbum.objects.all()
    return render(request, 'album.html', {'memories': memories})

def cart_view(request):
 
    if request.method == 'POST':
        form =UserRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            # پیام موفقیت یا ریدایرکت
    else:
        form = UserRegistrationForm()
    
    return render(request, 'cart.html', {'form': form})


def clases(request):
    return render(request, 'clases.html')
