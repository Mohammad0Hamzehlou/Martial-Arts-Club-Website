from django.contrib import admin
from .models import UserRegistration

@admin.register(UserRegistration)
class UserRegistrationAdmin(admin.ModelAdmin):
    list_display = ('name', 'age', 'phone_number', 'address', 'created_at')
    search_fields = ('name', 'phone_number', 'address')
    fields = ('name', 'age', 'message', 'payment_receipt', 'phone_number', 'address', 'profile_picture')

    class Media:
        css = {
            'all': ('css/admin_style.css',)  # استایل‌ها فقط در بخش ادمین بارگذاری می‌شوند
        }
        js = (
            'js/admin_script.js',  # اگر نیاز به جاوااسکریپت خاصی برای بخش ادمین دارید
        )
