from django import forms
from .models import UserRegistration

class UserRegistrationForm(forms.ModelForm):
    class Meta:
        model = UserRegistration
        fields = ['name', 'age', 'message', 'payment_receipt', 'phone_number', 'address', 'profile_picture']
