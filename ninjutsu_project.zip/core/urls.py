from django.urls import path
from . import views

urlpatterns = [
    path('', views.homepage, name='homepage'),
    path('register/', views.register, name='register'),
    path('album/', views.memory_album, name='album'),
    path('cart/',views.cart_view, name='cart'),
    path('clases/',views.clases, name='clases'),
]
